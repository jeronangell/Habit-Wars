package visualAspects;

import application.TaskActionControler;

public class MenuActions {
	//TaskActionControler tak=new TaskActionControler();
	public void logout() {
		System.out.println("logging out");
		//tak.reset();
	}

}
