package application;

public class UserStats {

	public int goldreward;
	public int mana;
	public int exp;
	public int perception;
	public int intelligence;
	public int constitution;
	public int strength;
}
